"""
=========================================================
Blink Detector V6
Simple Robust Blink Detector
Designed for BioAmp EXG + ADS1115
=========================================================
"""

import time
from collections import deque
import numpy as np

import config


class BlinkDetector:

    def __init__(self):

        # ---------------------------------
        # Configuration
        # ---------------------------------

        self.window = deque(maxlen=5)

        self.threshold = 800

        self.deadzone = 120

        self.min_width = 8

        self.max_width = 60

        self.group_timeout = 0.8

        self.refractory = 0.25

        # ---------------------------------
        # Runtime
        # ---------------------------------

        self.state = "IDLE"

        self.prev = 0

        self.filtered = 0

        self.sample = 0

        self.start_sample = 0

        self.peak = 0

        self.last_blink = 0

        self.pending = []

        self.debug = True

    # ---------------------------------

    def configure(self, calibration):

        self.deadzone = max(
            calibration.deadzone_y,
            config.MIN_DEADZONE
        )

        self.threshold = max(
            calibration.blink_threshold *
            config.BLINK_THRESHOLD_SCALE,
            config.MIN_BLINK_THRESHOLD
        )

        print("\n==============================")
        print("Blink Detector Ready")
        print("==============================")
        print("Threshold :", self.threshold)
        print("Deadzone  :", self.deadzone)
        print("==============================\n")

    # =====================================================
    # Update
    # =====================================================

    def update(self, signal):

        self.sample += 1

        # ---------------------------------------
        # Moving Average
        # ---------------------------------------

        self.window.append(signal)

        self.filtered = float(np.mean(self.window))

        slope = self.filtered - self.prev

        self.prev = self.filtered

        now = time.time()

        # ---------------------------------------
        # Check completed groups first
        # ---------------------------------------

        event = self.check_group()

        if event is not None:
            return event

        # ---------------------------------------
        # Refractory
        # ---------------------------------------

        if (now - self.last_blink) < self.refractory:
            return None

        # =======================================
        # IDLE
        # =======================================

        if self.state == "IDLE":

            if (
                self.filtered > self.threshold
                and slope > 40
            ):

                self.state = "PEAK"

                self.start_sample = self.sample

                self.peak = self.filtered

                if self.debug:
                    print(f"Blink Started : {self.filtered:.1f}")

            return None

        # =======================================
        # PEAK
        # =======================================

        elif self.state == "PEAK":

            if self.filtered > self.peak:
                self.peak = self.filtered

            width = self.sample - self.start_sample

            # Peak completed

            if slope <= 0:

                self.state = "RETURN"

                if self.debug:
                    print(f"Peak : {self.peak:.1f}")

            elif width > self.max_width:

                self.state = "IDLE"

                if self.debug:
                    print("Rejected : Too Wide")

            return None

        # =======================================
        # RETURN
        # =======================================

        elif self.state == "RETURN":

            width = self.sample - self.start_sample

            # Accept blink when signal falls
            # below 50% of peak

            if self.filtered < self.peak * 0.50:

                if self.min_width <= width <= self.max_width:

                    self.pending.append(now)

                    self.last_blink = now

                    if self.debug:

                        print(
                            f"Blink Accepted "
                            f"Peak={self.peak:.1f} "
                            f"Width={width}"
                        )

                else:

                    if self.debug:
                        print("Rejected : Width")

                self.state = "IDLE"

                self.peak = 0

            elif width > self.max_width:

                # Timeout acceptance

                self.pending.append(now)

                self.last_blink = now

                if self.debug:
                    print("Blink Accepted (Timeout)")

                self.state = "IDLE"

                self.peak = 0

            event = self.check_group()
            if event is not None:
                return event

            return None

    # =====================================================
    # Check Blink Group
    # =====================================================

    def check_group(self):

        # No accepted blinks yet
        if len(self.pending) == 0:
            return None

        now = time.time()

        # Time since the most recent accepted blink
        elapsed = now - self.pending[-1]

        # Still waiting for another blink
        if elapsed < self.group_timeout:
            return None

        # Decide the gesture
        count = len(self.pending)

        # Reset for next gesture
        self.pending.clear()

        if self.debug:
            print("\n==============================")
            print(f"Blink Group : {count}")
            print("==============================")

        # ----------------------------
        # Single Blink
        # ----------------------------

        if count == 1:

            if self.debug:
                print("Single Blink")

            return None

        # ----------------------------
        # Double Blink
        # ----------------------------

        elif count == 2:

            print("\n==============================")
            print("DOUBLE BLINK DETECTED")
            print("==============================\n")

            return "DOUBLE"

        # ----------------------------
        # Triple Blink
        # ----------------------------

        elif count >= 3:

            print("\n==============================")
            print("TRIPLE BLINK DETECTED")
            print("==============================\n")

            return "TRIPLE"

        return None