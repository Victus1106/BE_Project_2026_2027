"""
=========================================================
Eye Movement Detector V2.0

Uses

• Dynamic Deadzone
• Hysteresis
• Velocity Mapping
• Center Lock

=========================================================
"""


class EyeMovementDetector:

    def __init__(self):

        # Calibration values
        self.deadzone_x = 0
        self.deadzone_y = 0

        # Hysteresis

        self.enter_factor = 1.4
        self.exit_factor = 0.8

        # State

        self.horizontal_state = "CENTER"
        self.vertical_state = "CENTER"

        # Maximum expected EOG value

        self.max_signal = 2500

        # Maximum GUI speed

        self.max_speed = 5

    # -------------------------------------------------

    def configure(self, calibration):

        self.deadzone_x = calibration.deadzone_x

        self.deadzone_y = calibration.deadzone_y

    # -------------------------------------------------

    def velocity(self, value, deadzone):

        if abs(value) <= deadzone:

            return 0

        value = max(

            -self.max_signal,

            min(

                self.max_signal,

                value

            )

        )

        speed = (

            abs(value) - deadzone

        ) / (

            self.max_signal - deadzone

        )

        speed *= self.max_speed

        if value < 0:

            speed *= -1

        return speed

    # -------------------------------------------------

    def process(

        self,

        horizontal,

        vertical

    ):

        vx = 0

        vy = 0

        # =====================================
        # Horizontal
        # =====================================

        if self.horizontal_state == "CENTER":

            if horizontal > self.deadzone_x * self.enter_factor:

                self.horizontal_state = "RIGHT"

            elif horizontal < -self.deadzone_x * self.enter_factor:

                self.horizontal_state = "LEFT"

        elif self.horizontal_state == "RIGHT":

            if horizontal < self.deadzone_x * self.exit_factor:

                self.horizontal_state = "CENTER"

        elif self.horizontal_state == "LEFT":

            if horizontal > -self.deadzone_x * self.exit_factor:

                self.horizontal_state = "CENTER"

        # =====================================
        # Vertical
        # =====================================

        if self.vertical_state == "CENTER":

            if vertical > self.deadzone_y * self.enter_factor:

                self.vertical_state = "UP"

            elif vertical < -self.deadzone_y * self.enter_factor:

                self.vertical_state = "DOWN"

        elif self.vertical_state == "UP":

            if vertical < self.deadzone_y * self.exit_factor:

                self.vertical_state = "CENTER"

        elif self.vertical_state == "DOWN":

            if vertical > -self.deadzone_y * self.exit_factor:

                self.vertical_state = "CENTER"

        # =====================================
        # Velocity
        # =====================================

        if self.horizontal_state == "RIGHT":

            vx = self.velocity(

                horizontal,

                self.deadzone_x

            )

        elif self.horizontal_state == "LEFT":

            vx = self.velocity(

                horizontal,

                self.deadzone_x

            )

        if self.vertical_state == "UP":

            vy = self.velocity(

                vertical,

                self.deadzone_y

            )

        elif self.vertical_state == "DOWN":

            vy = self.velocity(

                vertical,

                self.deadzone_y

            )

        return {

            "vx": vx,

            "vy": vy,

            "horizontal_state": self.horizontal_state,

            "vertical_state": self.vertical_state

        }