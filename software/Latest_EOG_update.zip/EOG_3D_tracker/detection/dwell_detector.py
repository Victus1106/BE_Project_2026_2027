"""
=========================================================
Dwell Detector V2.0
Velocity-Based Dwell Detection
=========================================================
"""

import time


class DwellDetector:

    def __init__(self):

        # Seconds required for selection
        self.dwell_time = 1.5

        # Velocity threshold
        self.velocity_threshold = 0.25

        # Timer
        self.start_time = None

        # Cooldown after selection
        self.cooldown = 0.75

        self.last_selection = 0.0

        self.selected = False

    # -------------------------------------------------

    def reset(self):

        self.start_time = None

        self.selected = False

        self.last_selection = time.time()

    # -------------------------------------------------

    def update(self, vx, vy):

        now = time.time()

        # ----------------------------------------
        # Cooldown
        # ----------------------------------------

        if (now - self.last_selection) < self.cooldown:

            return False, 0.0

        # ----------------------------------------
        # Eye moving?
        # ----------------------------------------

        moving = (
            abs(vx) > self.velocity_threshold
            or
            abs(vy) > self.velocity_threshold
        )

        # ----------------------------------------
        # Reset timer while moving
        # ----------------------------------------

        if moving:

            self.start_time = None

            self.selected = False

            return False, 0.0

        # ----------------------------------------
        # Start dwell timer
        # ----------------------------------------

        if self.start_time is None:

            self.start_time = now

            return False, 0.0

        # ----------------------------------------
        # Elapsed time
        # ----------------------------------------

        elapsed = now - self.start_time

        if elapsed >= self.dwell_time:

            if not self.selected:

                self.selected = True

                self.last_selection = now

                return True, elapsed

        return False, elapsed