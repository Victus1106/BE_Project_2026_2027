from PyQt6.QtWidgets import *
from PyQt6.QtCore import *
from PyQt6.QtGui import *

from gui.top_view import TopView
from gui.side_view import SideView
from gui.status_panel import StatusPanel


class MainWindow(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle("EOG 3D Target Selection System")

        self.resize(1200, 700)

        # =====================================================
        # Central Widget
        # =====================================================

        central = QWidget()

        self.setCentralWidget(central)

        layout = QVBoxLayout()

        central.setLayout(layout)

        # =====================================================
        # Title
        # =====================================================

        title = QLabel("EOG BASED 3D TARGET SELECTION SYSTEM")

        title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title.setStyleSheet("""
            QLabel{
                font-size:22px;
                font-weight:bold;
                color:#003366;
            }
        """)

        layout.addWidget(title)

        # =====================================================
        # Views
        # =====================================================

        views = QHBoxLayout()

        layout.addLayout(views)

        self.top = TopView()
        self.side = SideView()

        views.addWidget(self.top)
        views.addWidget(self.side)

        # =====================================================
        # Status
        # =====================================================

        self.status = StatusPanel()

        layout.addWidget(self.status)

        # =====================================================
        # Remember last positions
        # =====================================================

        self.last_x = 50
        self.last_y = 50
        self.last_z = 0

        self.current_mode = "TOP_VIEW"

        self.update_gui(
            50,
            50,
            0,
            "TOP_VIEW",
            "TRACKING",
            0
        )

    # =========================================================

    def update_gui(
        self,
        x,
        y,
        z,
        mode,
        status,
        blink
    ):

        # Save latest position

        self.last_x = x
        self.last_y = y
        self.last_z = z

        self.current_mode = mode

        # ============================================
        # TOP VIEW MODE
        # ============================================

        if mode == "TOP_VIEW":

            self.top.update_position(
                x,
                y
            )

            # Side View intentionally NOT updated

        # ============================================
        # SIDE VIEW MODE
        # ============================================

        elif mode == "SIDE_VIEW":

            self.side.update_position(
                self.last_x,
                z
            )

            # Top View intentionally NOT updated

        # ============================================
        # LOCKED
        # ============================================

        elif mode == "LOCKED":

            pass

        # ============================================

        self.status.update_status(

            mode,

            status,

            blink,

            self.last_x,

            self.last_y,

            self.last_z

        )

    # =========================================================

    def reset_gui(self):

        self.last_x = 50
        self.last_y = 50
        self.last_z = 0

        self.current_mode = "TOP_VIEW"

        self.top.update_position(50, 50)

        self.side.update_position(50, 0)

        self.status.update_status(

            "TOP_VIEW",

            "TRACKING",

            0,

            50,

            50,

            0

        )