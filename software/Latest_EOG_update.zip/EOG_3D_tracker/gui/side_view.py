from PyQt6.QtWidgets import QWidget
from PyQt6.QtGui import *
from PyQt6.QtCore import *


class SideView(QWidget):

    def __init__(self):

        super().__init__()

        self.x = 50
        self.z = 0

        self.setMinimumSize(450, 450)

    # -------------------------------------------------

    def update_position(self, x, z):

        self.x = x
        self.z = z

        self.update()

    # -------------------------------------------------

    def paintEvent(self, event):

        painter = QPainter(self)

        painter.fillRect(
            self.rect(),
            Qt.GlobalColor.white
        )

        painter.setRenderHint(
            QPainter.RenderHint.Antialiasing
        )

        painter.setPen(
            QPen(Qt.GlobalColor.black, 2)
        )

        # Workspace

        painter.drawRect(
            20,
            20,
            400,
            400
        )

        # Grid

        painter.setPen(
            QPen(Qt.GlobalColor.lightGray, 1)
        )

        for i in range(1, 10):

            painter.drawLine(
                20 + i * 40,
                20,
                20 + i * 40,
                420
            )

            painter.drawLine(
                20,
                20 + i * 40,
                420,
                20 + i * 40
            )

        # Labels

        painter.setPen(
            Qt.GlobalColor.black
        )

        painter.drawText(
            170,
            15,
            "SIDE VIEW (X-Z)"
        )

        painter.drawText(
            430,
            425,
            "X"
        )

        painter.drawText(
            5,
            25,
            "Z"
        )

        # Ball

        px = 20 + self.x * 4

        py = 420 - self.z * 4

        painter.setBrush(
            Qt.GlobalColor.red
        )

        painter.drawEllipse(
            QPointF(px, py),
            8,
            8
        )