from PyQt6.QtWidgets import QWidget

from PyQt6.QtGui import *

from PyQt6.QtCore import *


class TopView(QWidget):

    def __init__(self):

        super().__init__()

        self.x = 50

        self.y = 50

        self.setMinimumSize(

            450,

            450

        )

    def update_position(self,x,y):

        self.x=x

        self.y=y

        self.update()

    def paintEvent(self,e):

        painter=QPainter(self)

        painter.fillRect(

            self.rect(),

            Qt.GlobalColor.white

        )

        painter.setPen(QPen(Qt.GlobalColor.black,2))

        painter.drawRect(

            20,

            20,

            400,

            400

        )

        px=20+self.x*4

        py=420-self.y*4

        painter.setBrush(

            Qt.GlobalColor.blue

        )

        painter.drawEllipse(

            QPointF(px,py),

            8,

            8
        )