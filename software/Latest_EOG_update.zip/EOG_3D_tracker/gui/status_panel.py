from PyQt6.QtWidgets import *
from PyQt6.QtCore import *


class StatusPanel(QWidget):

    def __init__(self):

        super().__init__()

        layout = QGridLayout()

        self.setLayout(layout)

        font = self.font()

        font.setPointSize(11)

        # --------------------------

        self.modeLabel = QLabel("TOP VIEW")

        self.statusLabel = QLabel("TRACKING")

        self.blinkLabel = QLabel("0")

        self.xLabel = QLabel("50.0")

        self.yLabel = QLabel("50.0")

        self.zLabel = QLabel("0.0")

        self.modeLabel.setFont(font)

        self.statusLabel.setFont(font)

        self.blinkLabel.setFont(font)

        self.xLabel.setFont(font)

        self.yLabel.setFont(font)

        self.zLabel.setFont(font)

        # --------------------------

        layout.addWidget(QLabel("MODE"), 0, 0)

        layout.addWidget(self.modeLabel, 0, 1)

        layout.addWidget(QLabel("STATUS"), 1, 0)

        layout.addWidget(self.statusLabel, 1, 1)

        layout.addWidget(QLabel("BLINK COUNT"), 2, 0)

        layout.addWidget(self.blinkLabel, 2, 1)

        layout.addWidget(QLabel("X"), 3, 0)

        layout.addWidget(self.xLabel, 3, 1)

        layout.addWidget(QLabel("Y"), 4, 0)

        layout.addWidget(self.yLabel, 4, 1)

        layout.addWidget(QLabel("Z"), 5, 0)

        layout.addWidget(self.zLabel, 5, 1)

    # -------------------------------------------------

    def update_status(
            self,
            mode,
            status,
            blink,
            x,
            y,
            z
    ):

        self.modeLabel.setText(str(mode))

        self.statusLabel.setText(str(status))

        self.blinkLabel.setText(str(blink))

        self.xLabel.setText(f"{x:.2f}")

        self.yLabel.setText(f"{y:.2f}")

        self.zLabel.setText(f"{z:.2f}")