"""
=========================================================
Real-Time Signal Processing V2
=========================================================
"""

from signal_processing.filters import SignalFilters
from signal_processing.kalman import Kalman1D


class SignalProcessor:

    def __init__(self, calibration):

        self.calibration = calibration

        self.filters = SignalFilters(250)

        self.kalman_x = Kalman1D()

        self.kalman_y = Kalman1D()

    # -------------------------------------------------

    def process_sample(self,
                       horizontal,
                       vertical):

        # -------------------------------------
        # Remove Calibration Baseline
        # -------------------------------------

        horizontal = horizontal - self.calibration.baseline_x

        vertical = vertical - self.calibration.baseline_y

        # -------------------------------------
        # Streaming Filters
        # -------------------------------------

        horizontal, vertical = self.filters.process(

            horizontal,

            vertical

        )

        # -------------------------------------
        # Kalman
        # -------------------------------------

        horizontal = self.kalman_x.process(horizontal)

        vertical = self.kalman_y.process(vertical)

        return horizontal, vertical