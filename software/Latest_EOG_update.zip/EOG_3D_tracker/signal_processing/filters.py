"""
=========================================================
Streaming Digital Filters
=========================================================

Real-time Filters

Input:
    One sample at a time

Output:
    One filtered sample

=========================================================
"""

import numpy as np
from scipy.signal import butter, iirnotch, lfilter, lfilter_zi


class StreamingFilter:

    def __init__(self, b, a):

        self.b = b
        self.a = a

        # Initialize filter state
        self.zi = lfilter_zi(b, a) * 0

    def process(self, sample):

        y, self.zi = lfilter(
            self.b,
            self.a,
            [sample],
            zi=self.zi
        )

        return float(y[0])


class SignalFilters:

    def __init__(self, fs):

        # ------------------------
        # 50Hz Notch
        # ------------------------

        b_notch, a_notch = iirnotch(
            w0=50,
            Q=30,
            fs=fs
        )

        self.notch_x = StreamingFilter(
            b_notch,
            a_notch
        )

        self.notch_y = StreamingFilter(
            b_notch,
            a_notch
        )

        # ------------------------
        # Butterworth Bandpass
        # ------------------------

        b_band, a_band = butter(
            N=4,
            Wn=[0.1, 10],
            btype="bandpass",
            fs=fs
        )

        self.band_x = StreamingFilter(
            b_band,
            a_band
        )

        self.band_y = StreamingFilter(
            b_band,
            a_band
        )

    # --------------------------------

    def process(self, horizontal, vertical):

        hx = self.notch_x.process(horizontal)
        hy = self.notch_y.process(vertical)

        hx = self.band_x.process(hx)
        hy = self.band_y.process(hy)

        return hx, hy