"""
=========================================================
1D Streaming Kalman Filter
=========================================================
"""


class Kalman1D:

    def __init__(self,
                 process_noise=0.005,
                 measurement_noise=12.0):

        self.q = process_noise
        self.r = measurement_noise

        self.x = 0.0
        self.p = 1.0

        self.initialized = False

    # ----------------------------------------

    def process(self, measurement):

        if not self.initialized:

            self.x = measurement
            self.initialized = True
            return measurement

        # Prediction
        self.p += self.q

        # Kalman Gain
        k = self.p / (self.p + self.r)

        # Update
        self.x = self.x + k * (measurement - self.x)

        self.p = (1 - k) * self.p

        return self.x