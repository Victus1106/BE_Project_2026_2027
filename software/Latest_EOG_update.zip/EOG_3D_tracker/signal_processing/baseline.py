"""
=========================================================
Adaptive Baseline Tracker
=========================================================
"""


class BaselineTracker:

    def __init__(self,
                 alpha=0.001):

        self.alpha = alpha

        self.baseline = None

    # ----------------------------------------

    def process(self, value):

        if self.baseline is None:

            self.baseline = value

        self.baseline = (

            (1 - self.alpha) * self.baseline +

            self.alpha * value

        )

        return value - self.baseline