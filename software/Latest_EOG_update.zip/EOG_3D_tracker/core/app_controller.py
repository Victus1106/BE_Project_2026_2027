"""
=========================================================
Application Controller V4.0
Dwell-Time Based Control
=========================================================
"""

from serial_io.serial_reader import SerialReader

from signal_processing.preprocessing import SignalProcessor

from detection.eye_detector import EyeMovementDetector
from detection.dwell_detector import DwellDetector

from controller.state_machine import StateMachine
from controller.position_controller import PositionController

from calibration.calibration_manager import CalibrationManager


class ApplicationController:

    def __init__(self, window):

        self.window = window

        # ==================================================
        # SERIAL
        # ==================================================

        self.reader = SerialReader()
        self.reader.connect()
        self.reader.start()

        # ==================================================
        # CALIBRATION
        # ==================================================

        self.calibration = CalibrationManager()
        self.calibration.start()

        # ==================================================
        # PROCESSING MODULES
        # ==================================================

        self.processor = SignalProcessor(self.calibration)

        self.eye = EyeMovementDetector()

        self.dwell = DwellDetector()

        self.state = StateMachine()

        self.position = PositionController()

        # ==================================================

        self.eye_configured = False

        self.status = "CALIBRATION"

        self.dwell_progress = 0.0

    # ==================================================
    # Main Update Loop
    # ==================================================

    def update(self):

        sample = self.reader.latest()

        if sample is None:
            return

        timestamp, horizontal, vertical = sample

        # ==================================================
        # CALIBRATION
        # ==================================================

        if not self.calibration.calibrated():

            self.calibration.update(
                horizontal,
                vertical
            )

            self.window.update_gui(

                50,
                50,
                0,

                "CALIBRATION",

                "LOOK STRAIGHT",

                "0.0 s"

            )

            if self.calibration.calibrated():

                print("\n===================================")
                print("Calibration Finished")
                print("===================================\n")

                self.eye.configure(
                    self.calibration
                )

                self.eye_configured = True

                self.state.calibration_complete()

            return

        # ==================================================
        # SAFETY
        # ==================================================

        if not self.eye_configured:
            return

        # ==================================================
        # SIGNAL PROCESSING
        # ==================================================

        filtered_horizontal, filtered_vertical = (

            self.processor.process_sample(

                horizontal,

                vertical

            )

        )

        # ==================================================
        # EYE DETECTOR
        # ==================================================

        movement = self.eye.process(

            filtered_horizontal,

            filtered_vertical

        )

        vx = movement["vx"]

        vy = movement["vy"]

        current_state = self.state.current_state()

        # ==================================================
        # MODE DEPENDENT CONTROL
        # ==================================================

        if current_state.name == "TOP_VIEW":

            # Normal X,Y movement
            pass

        elif current_state.name == "SIDE_VIEW":

            # Ignore horizontal movement in side view
            vx = 0

        elif current_state.name == "LOCKED":

            # Freeze cursor
            vx = 0
            vy = 0

        # ==================================================
        # POSITION CONTROLLER
        # ==================================================

        self.position.update(
            current_state,
            vx,
            vy
        )

        pos = self.position.get_position()

        # ==================================================
        # DWELL DETECTOR
        # ==================================================

        selected = False
        elapsed = 0.0

        if current_state.name in ("TOP_VIEW", "SIDE_VIEW"):

            selected, elapsed = self.dwell.update(
                vx,
                vy
            )

        self.dwell_progress = elapsed

        # ==================================================
        # DWELL EVENT
        # ==================================================

        if selected:

            print("\n==============================")
            print("DWELL COMPLETED")
            print("==============================")

            self.state.dwell_complete()

            # Reset dwell detector for next state
            self.dwell.reset()

            # Refresh state after transition
            current_state = self.state.current_state()

            # Skip the rest of this frame
            return

        # ==================================================
        # REFRESH STATE
        # ==================================================

        current_state = self.state.current_state()

        # ==================================================
        # STATUS
        # ==================================================

        if current_state.name == "TOP_VIEW":

            self.status = (
                f"TOP VIEW | "
                f"Dwell {self.dwell_progress:.1f}/1.5 s"
            )

        elif current_state.name == "SIDE_VIEW":

            self.status = (
                f"SIDE VIEW | "
                f"Dwell {self.dwell_progress:.1f}/1.5 s"
            )

        elif current_state.name == "LOCKED":

            self.status = "TARGET LOCKED"

        else:

            self.status = "CALIBRATION"

        # ==================================================
        # GUI UPDATE
        # ==================================================

        self.window.update_gui(

            pos["x"],
            pos["y"],
            pos["z"],

            current_state.name,

            self.status,

            f"{self.dwell_progress:.1f}s"

        )

        # ==================================================
        # DEBUG
        # ==================================================
        """
        print(
            f"State={current_state.name}",
            f"H={filtered_horizontal:.1f}",
            f"V={filtered_vertical:.1f}",
            f"VX={vx:.2f}",
            f"VY={vy:.2f}",
            f"Pos=({pos['x']:.1f}, "
            f"{pos['y']:.1f}, "
            f"{pos['z']:.1f})"
        )
        """