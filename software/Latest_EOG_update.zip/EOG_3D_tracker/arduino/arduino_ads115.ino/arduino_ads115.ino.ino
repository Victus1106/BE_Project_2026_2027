/*
=========================================================
EOG 3D Tracking System
Module 1 : ADS1115 Data Acquisition

Hardware:
- Arduino UNO
- ADS1115
- 2 x BioAmp EXG Pill

Sampling Rate : 250 Hz
Output Format:
timestamp_us,horizontal,vertical

Author : Shrawan Rane
=========================================================
*/

#include <Wire.h>
#include <Adafruit_ADS1X15.h>

Adafruit_ADS1115 ads;

// =========================================================
// CONFIGURATION
// =========================================================

const uint32_t SAMPLE_PERIOD_US = 4000;     // 250 Hz

uint32_t previousSample = 0;

// =========================================================

void setup()
{
    Serial.begin(115200);

    while (!Serial);

    Wire.begin();

    Serial.println();
    Serial.println("==========================================");
    Serial.println("EOG Acquisition System");
    Serial.println("Initializing ADS1115...");
    Serial.println("==========================================");

    if (!ads.begin())
    {
        Serial.println("ERROR : ADS1115 NOT DETECTED!");

        while (1);
    }

    /*
        Gain Selection

        GAIN_TWO

        Range:
        ±2.048V

        Resolution:
        62.5 uV/bit

        Better suited for BioAmp EXG output.
    */

    ads.setGain(GAIN_TWO);
    ads.setDataRate(RATE_ADS1115_250SPS);

    Serial.println("ADS1115 Detected");
    Serial.println("Gain           : GAIN_TWO");
    Serial.println("Sampling Rate  : 250 Hz");
    Serial.println("Output         : timestamp,horizontal,vertical");
    Serial.println("==========================================");

    // CSV Header
    Serial.println("timestamp,horizontal,vertical");

    previousSample = micros();
}

// =========================================================

void loop()
{
    uint32_t now = micros();

    if ((now - previousSample) >= SAMPLE_PERIOD_US)
    {
        previousSample = now;

        // Read Channels
        int16_t horizontal = ads.readADC_SingleEnded(0);
        int16_t vertical   = ads.readADC_SingleEnded(1);

        // Send CSV
        Serial.print(now);
        Serial.print(",");
        Serial.print(horizontal);
        Serial.print(",");
        Serial.println(vertical);
    }
}