"""
=========================================================
Calibration Manager V2.0
Robust Calibration for EOG
=========================================================
"""

import numpy as np
import time


class CalibrationManager:

    def __init__(self):

        # -------------------------------
        # Timing
        # -------------------------------

        self.wait_time = 2.0          # Wait before calibration
        self.calibration_time = 3.0   # Collect data

        self.state = "WAIT"

        self.start_time = None

        self.samples_h = []
        self.samples_v = []

        self.finished = False

        # -------------------------------
        # Results
        # -------------------------------

        self.baseline_x = 0
        self.baseline_y = 0

        self.noise_x = 0
        self.noise_y = 0

        self.deadzone_x = 0
        self.deadzone_y = 0

        self.blink_threshold = 0

    # ==================================================

    def start(self):

        print("\n========================================")
        print("EOG CALIBRATION")
        print("Keep Looking Straight")
        print("Relax Your Eyes")
        print("========================================\n")

        self.samples_h.clear()
        self.samples_v.clear()

        self.finished = False

        self.state = "WAIT"

        self.start_time = time.time()

    # ==================================================

    def update(self, horizontal, vertical):

        if self.finished:
            return

        elapsed = time.time() - self.start_time

        # ------------------------------------------
        # WAIT FOR HARDWARE TO STABILIZE
        # ------------------------------------------

        if self.state == "WAIT":

            if elapsed >= self.wait_time:

                print("Collecting Calibration Data...\n")

                self.state = "COLLECT"

                self.start_time = time.time()

            return

        # ------------------------------------------
        # COLLECT DATA
        # ------------------------------------------

        self.samples_h.append(horizontal)
        self.samples_v.append(vertical)

        if time.time() - self.start_time >= self.calibration_time:

            self.finish()

    # ==================================================

    def finish(self):

        h = np.array(self.samples_h)
        v = np.array(self.samples_v)

        # ------------------------------------------
        # Median Baseline
        # ------------------------------------------

        median_h = np.median(h)
        median_v = np.median(v)

        # ------------------------------------------
        # Reject Outliers
        # ------------------------------------------

        keep_h = np.abs(h - median_h) < 800
        keep_v = np.abs(v - median_v) < 800

        h = h[keep_h]
        v = v[keep_v]

        # Safety

        if len(h) < 50:
            h = np.array(self.samples_h)

        if len(v) < 50:
            v = np.array(self.samples_v)

        # ------------------------------------------
        # Final Baseline
        # ------------------------------------------

        self.baseline_x = np.median(h)
        self.baseline_y = np.median(v)

        # ------------------------------------------
        # MAD Noise Estimate
        # ------------------------------------------

        mad_h = np.median(np.abs(h - self.baseline_x))
        mad_v = np.median(np.abs(v - self.baseline_y))

        # Convert MAD to std estimate

        self.noise_x = mad_h * 1.4826
        self.noise_y = mad_v * 1.4826

        # ------------------------------------------
        # Deadzone
        # ------------------------------------------

        self.deadzone_x = max(120, self.noise_x * 2.5)
        self.deadzone_y = max(120, self.noise_y * 2.5)

        # ------------------------------------------
        # Blink Threshold
        # ------------------------------------------

        self.blink_threshold = max(700, self.noise_y * 4)

        self.finished = True

        # ------------------------------------------
        # Print Results
        # ------------------------------------------

        print("\n========================================")
        print("Calibration Complete")
        print("========================================")

        print(f"Baseline X      : {self.baseline_x:.2f}")
        print(f"Baseline Y      : {self.baseline_y:.2f}")

        print()

        print(f"Noise X         : {self.noise_x:.2f}")
        print(f"Noise Y         : {self.noise_y:.2f}")

        print()

        print(f"Deadzone X      : {self.deadzone_x:.2f}")
        print(f"Deadzone Y      : {self.deadzone_y:.2f}")

        print()

        print(f"Blink Threshold : {self.blink_threshold:.2f}")

        print("========================================\n")

    # ==================================================

    def calibrated(self):

        return self.finished