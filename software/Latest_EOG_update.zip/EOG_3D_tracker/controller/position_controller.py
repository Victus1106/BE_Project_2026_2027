"""
=========================================================
Position Controller V3.0

TOP VIEW

Horizontal -> X
Vertical   -> Y

SIDE VIEW

Vertical   -> Z

LOCKED

Position Frozen
=========================================================
"""

from controller.state_machine import State


class PositionController:

    def __init__(self):

        # ------------------------------------
        # Initial Position
        # ------------------------------------

        self.x = 50.0
        self.y = 50.0
        self.z = 0.0

        # ------------------------------------
        # Cursor Speed
        # ------------------------------------

        self.speed = 0.25

        # ------------------------------------
        # Axis Inversion
        # Change these if movement is opposite
        # ------------------------------------

        self.INVERT_X = False
        self.INVERT_Y = False
        self.INVERT_Z = False

        # ------------------------------------
        # Workspace Limits
        # ------------------------------------

        self.X_MIN = 0
        self.X_MAX = 100

        self.Y_MIN = 0
        self.Y_MAX = 100

        self.Z_MIN = 0
        self.Z_MAX = 100

    # =====================================================

    def clamp(self):

        self.x = max(self.X_MIN, min(self.X_MAX, self.x))
        self.y = max(self.Y_MIN, min(self.Y_MAX, self.y))
        self.z = max(self.Z_MIN, min(self.Z_MAX, self.z))

    # =====================================================

    def update(self, state, vx, vy):

        # ------------------------------------
        # Apply Axis Inversion
        # ------------------------------------

        if self.INVERT_X:
            vx = -vx

        if self.INVERT_Y:
            vy = -vy

        # ------------------------------------
        # TOP VIEW
        # ------------------------------------

        if state == State.TOP_VIEW:

            self.x += vx * self.speed
            self.y += vy * self.speed

        # ------------------------------------
        # SIDE VIEW
        # ------------------------------------

        elif state == State.SIDE_VIEW:

            z_velocity = -vy if self.INVERT_Z else vy

            self.z += z_velocity * self.speed

        # ------------------------------------
        # LOCKED
        # ------------------------------------

        elif state == State.LOCKED:

            return

        # ------------------------------------

        self.clamp()

    # =====================================================

    def reset(self):

        self.x = 50.0
        self.y = 50.0
        self.z = 0.0

    # =====================================================

    def get_position(self):

        return {

            "x": self.x,
            "y": self.y,
            "z": self.z

        }