"""
=========================================================
Finite State Machine V4.0
Dwell-Time Based State Machine
=========================================================
"""

from enum import Enum


class State(Enum):

    CALIBRATION = 0
    TOP_VIEW = 1
    SIDE_VIEW = 2
    LOCKED = 3


class StateMachine:

    def __init__(self):

        self.state = State.CALIBRATION

    # -------------------------------------------------

    def calibration_complete(self):

        self.state = State.TOP_VIEW

        print("\n===================================")
        print("Calibration Complete")
        print("Current Mode : TOP VIEW")
        print("===================================\n")

    # -------------------------------------------------

    def dwell_complete(self):
        """
        Called when the user keeps the cursor
        steady for the required dwell time.
        """

        # -------------------------------------
        # TOP VIEW -> SIDE VIEW
        # -------------------------------------

        if self.state == State.TOP_VIEW:

            self.state = State.SIDE_VIEW

            print("\n===================================")
            print("DWELL COMPLETED")
            print("Switched To SIDE VIEW")
            print("===================================\n")

            return

        # -------------------------------------
        # SIDE VIEW -> LOCKED
        # -------------------------------------

        if self.state == State.SIDE_VIEW:

            self.state = State.LOCKED

            print("\n===================================")
            print("DWELL COMPLETED")
            print("TARGET LOCKED")
            print("===================================\n")

            return

        # -------------------------------------

        if self.state == State.LOCKED:

            print("Target already locked.")

    # -------------------------------------------------

    def unlock(self):

        self.state = State.TOP_VIEW

        print("\n===================================")
        print("Target Unlocked")
        print("Current Mode : TOP VIEW")
        print("===================================\n")

    # -------------------------------------------------

    def current_state(self):

        return self.state