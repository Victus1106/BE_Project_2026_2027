"""
=========================================================
Module 2

Serial Reader

Reads Arduino ADS1115 data continuously.

Output

(timestamp, horizontal, vertical)

=========================================================
"""

import serial
import threading
from collections import deque

import config


class SerialReader:

    def __init__(self):

        self.serial = None

        self.running = False

        self.thread = None

        self.buffer = deque(maxlen=config.BUFFER_SIZE)

        self.lock = threading.Lock()

    # -------------------------------------------------

    def connect(self):

        self.serial = serial.Serial(

            config.COM_PORT,

            config.BAUD_RATE,

            timeout=1

        )

        print()

        print("-----------------------------------")
        print("Arduino Connected")
        print(config.COM_PORT)
        print("-----------------------------------")

    # -------------------------------------------------

    def start(self):

        self.running = True

        self.thread = threading.Thread(

            target=self.read_loop,

            daemon=True

        )

        self.thread.start()

    # -------------------------------------------------

    def stop(self):

        self.running = False

        if self.serial:

            self.serial.close()

    # -------------------------------------------------

    def read_loop(self):

        while self.running:

            try:

                line = self.serial.readline()

                line = line.decode(

                    errors="ignore"

                ).strip()

                if len(line) == 0:

                    continue

                # Ignore Arduino messages

                if line.startswith("EOG"):

                    continue

                if line.startswith("ADS"):

                    continue

                if line.startswith("="):

                    continue

                if line.startswith("timestamp"):

                    continue

                parts = line.split(",")

                if len(parts) != 3:

                    continue

                timestamp = int(parts[0])

                horizontal = int(parts[1])

                vertical = int(parts[2])

                with self.lock:

                    self.buffer.append(

                        (

                            timestamp,

                            horizontal,

                            vertical

                        )

                    )

            except Exception:

                continue

    # -------------------------------------------------

    def latest(self):

        with self.lock:

            if len(self.buffer) == 0:

                return None

            return self.buffer[-1]

    # -------------------------------------------------

    def latest_n(self, n):

        with self.lock:

            if len(self.buffer) < n:

                return list(self.buffer)

            return list(self.buffer)[-n:]

    # -------------------------------------------------

    def get_buffer(self):

        with self.lock:

            return list(self.buffer)

    # -------------------------------------------------

    def clear(self):

        with self.lock:

            self.buffer.clear()

    # -------------------------------------------------

    def size(self):

        with self.lock:

            return len(self.buffer)